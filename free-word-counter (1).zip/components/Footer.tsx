import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, FileText } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Column 1: Brand */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-brand-primary p-1.5 rounded text-gray-900">
                <FileText size={20} />
              </div>
              <span className="text-lg font-bold text-gray-800">Free Word Counter</span>
            </div>
            <p className="text-sm text-gray-500 leading-relaxed">
              The ultimate free online tool for students, writers, and professionals to count words, characters, and sentences instantly.
            </p>
            <div className="flex gap-4 mt-2">
              <a href="#" className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-brand-primary hover:text-gray-900 transition-colors"><Facebook size={18} /></a>
              <a href="#" className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-brand-primary hover:text-gray-900 transition-colors"><Twitter size={18} /></a>
              <a href="#" className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-brand-primary hover:text-gray-900 transition-colors"><Instagram size={18} /></a>
              <a href="#" className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-brand-primary hover:text-gray-900 transition-colors"><Linkedin size={18} /></a>
            </div>
          </div>

          {/* Column 2: Tool Links */}
          <div>
            <h4 className="text-gray-900 font-bold mb-6">Tools</h4>
            <ul className="space-y-3 text-sm text-gray-600">
              <li><Link to="/" className="hover:text-brand-primary transition-colors">Word Counter</Link></li>
              <li><Link to="/" className="hover:text-brand-primary transition-colors">Character Counter</Link></li>
              <li><Link to="/" className="hover:text-brand-primary transition-colors">Sentence Counter</Link></li>
              <li><Link to="/" className="hover:text-brand-primary transition-colors">Paragraph Counter</Link></li>
            </ul>
          </div>

          {/* Column 3: Company */}
          <div>
            <h4 className="text-gray-900 font-bold mb-6">Company</h4>
            <ul className="space-y-3 text-sm text-gray-600">
              <li><Link to="/about" className="hover:text-brand-primary transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-brand-primary transition-colors">Contact Us</Link></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Sitemap</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Blog</a></li>
            </ul>
          </div>

          {/* Column 4: Legal */}
          <div>
            <h4 className="text-gray-900 font-bold mb-6">Legal</h4>
            <ul className="space-y-3 text-sm text-gray-600">
              <li><Link to="/privacy" className="hover:text-brand-primary transition-colors">Privacy Policy</Link></li>
              <li><Link to="/disclaimer" className="hover:text-brand-primary transition-colors">Disclaimer</Link></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Cookie Policy</a></li>
            </ul>
          </div>

        </div>

        <div className="border-t border-gray-100 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} Free Word Counter. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;